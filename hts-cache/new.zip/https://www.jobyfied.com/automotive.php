
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-169269100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-169269100-1');
</script>
<script data-ad-client="ca-pub-9170822913059220" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Jobyfied</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700|Work+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">
    
    
    
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  
    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
	  <link rel="stylesheet" type="text/css"
          href="fonts/neo fobia/stylefont.css"/>
    
  </head>
  <body>
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->
    
    
     <div class="site-navbar-wrap js-site-navbar bg-white">
      
      <div class="container">
        <div class="site-navbar bg-light">
          <div class="py-1">
            <div class="row align-items-center">
              <div class="col-2">
                <h2 class="mb-0 site-logo"><a href="index.php" style="font-family:'Neo Fobia Bold';font-weight:normal;font-size:30px" >JOBYFIED</a></h2>
				<p style="font-size: 14.6px; color: black;">Simplyfing Job Search</p>
              </div>
              <div class="col-10">
                <nav class="site-navigation text-right" role="navigation">
                  <div class="container">
                    <div class="d-inline-block d-lg-none ml-md-0 mr-auto py-3"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

                    <ul class="site-menu js-clone-nav d-none d-lg-block">
                      <li><a href="postjob.php"><span class="bg-primary text-white py-3 px-4 rounded"><span class="icon-plus mr-3"></span>Post New Job</span></a></li>
                    </ul>
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  
    <div style="height: 113px;"></div>
	  
    <div class="unit-5 overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container text-center">
        <h2 class="mb-0">Automotive Jobs</h2>
        <p class="mb-0 unit-6"><a href="index.php">Home</a> <span class="sep">/</span> <span>Automotive Jobs</span></p>
      </div>
    </div>
	  <div class="container">
	  	  <div class="site-section bg-light">
	  <div class="col-md-12 block-16">
  <div class="d-flex mb-0">
              <h2 class="mb-5 h3 mb-0">Automotive Jobs</h2>
            </div>
	  </div>

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1336 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Drivers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1237 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Automotive Company Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1208 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Assistant Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1197 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Automotive Company Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1196 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Heavy Vehicle Drivers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1193 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Offshore Nurse</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>EMSA QATAR</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1184 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Break Down Vehicle Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1155 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Heavy Duty Drivers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span> Teyseer Building Materials</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1150 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Bike Drivers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1129 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1123 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1108 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HEAVY TRANSPORT DRIVERS</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1101 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Heavy Bus Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1076 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>A FURNITURE QATARI COMPANY JOBS</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1045 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> HEAVY TRANSPORTATION MANAGER / Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=993 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Forklift Driver - Riyadh city</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=937 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Light or Heavy Driver for KSA</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=883 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Need Mechanics Electrician for American & German C</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=880 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Indian Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=877 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> TANKER DRIVERS</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=847 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Motorcycle Drivers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=835 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DIESEL MECHANIC</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=832 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MACHINE OPERATOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=816 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MACHINE OPERATOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Khalifa Steel</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=803 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Jobs for Drivers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=798 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Motobike Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=795 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Hiring or Group of Companies in Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=793 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Local Hiring for Bike Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=789 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Hiring</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=742 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Courier Drivers Required</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=733 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Drivers for a logistic company (RIYADH) Full-time</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=719 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>YACHTS OUT BOARD ENGINE / SPEED BOAT MECHANIC</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=699 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Professional Personal driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=683 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=667 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>20 dyna drivers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=653 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Forklift Operator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=631 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Forklift Operators and Heavy Drivers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=612 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Bicycle Mechanic</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=603 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Heavy Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=576 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Overhead Crane Operator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=554 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Auto mechanic auto electrician for filipino only</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=516 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>General Labour / Light Driver </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Aastha Consulting</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=514 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Dyna Driver and Labors</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=507 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Couriers Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=500 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Machine Operator & Machine Technicians</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=499 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Car Washer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=495 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Machine Operator/Diesel Mechanic/ Auto Electricain</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=484 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Heavy driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=456 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=438 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Car Detailer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=434 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Forklift Operator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=431 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Asstistant Mechanic</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=429 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Machine Operator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>AAF Saudi Arabia Ltd</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=425 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Auto Electrician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=424 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DRIVER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=423 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Ambulance Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=411 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Light Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=409 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>House Driver / Company Driver / Light Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=403 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Heavy driver cum Equipment operator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=379 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Welding Inspector</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=378 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Welder</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=377 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Grinding Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=376 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Forklifter</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=374 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Mechanist</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=372 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Maintenance Technician-Automation</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=367 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Operator PLC/SCADA</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=365 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Tire/Tyre Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=364 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Service Mechanic</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=363 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engine Fitter</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=362 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Auto Electrician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=361 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DIESEL MECHANIC </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=317 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engine Mechanic</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=301 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=264 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HEAVY DRIVERS </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=263 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>LIGHT DRIVERS </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=262 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SHOVEL OPERATORS </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=261 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>FORKLIFT OPERATORS </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=260 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MOBILE CRANE OPERATORS </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=216 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MOTORCYCLE RIDER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=209 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=187 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=158 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MOTORCYCLE DRIVER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=134 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DRIVERS LIGHT & HEAVY TRUCK</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=127 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>CORRUGATED CARTON BOX – MACHINE OPERATORS </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=125 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DIESEL MECHANIC </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=122 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>TRAILER DRIVER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=121 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>TINTING CUM STICKER WORKER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=120 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>POLISHER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=119 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PAINTER VEHICLE </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=118 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>GENERAL HELPER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=117 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SUPERVISOR (ARABIC)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    
	 
</div>
   </div> 
    <footer class="site-footer">
      <div class="container">
         <div class="col-md-12 text-center">
                <p><a href="index.php" style="font-family:'Neo Fobia Bold';font-weight:normal;font-size:40px; color: #FFFFFF;" >JOBYFIED</a></p>
			    <p style="font-size: 16px; color: #FFFFFF;">Simplyfing Job Search</p>
              </div>
		  <br>
        <div class="text-center">
          <div class="col-md-12">
            <p style="color: white;">
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All Rights Reserved | This Website Made By <a href="http://www.digitadm.com/" style="color: green;">Digita Digital Marketing.</a>
            </p>
          </div>
          
        </div>
      </div>
    </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  
  <script src="js/mediaelement-and-player.min.js"></script>

  <script src="js/main.js"></script>
    

  <script>
      document.addEventListener('DOMContentLoaded', function() {
                var mediaElements = document.querySelectorAll('video, audio'), total = mediaElements.length;

                for (var i = 0; i < total; i++) {
                    new MediaElementPlayer(mediaElements[i], {
                        pluginPath: 'https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/',
                        shimScriptAccess: 'always',
                        success: function () {
                            var target = document.body.querySelectorAll('.player'), targetTotal = target.length;
                            for (var j = 0; j < targetTotal; j++) {
                                target[j].style.visibility = 'visible';
                            }
                  }
                });
                }
            });
    </script>


    <script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&libraries=places&callback=initAutocomplete"
        async defer></script>

  </body>
</html>