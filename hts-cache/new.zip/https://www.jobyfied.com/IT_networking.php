
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-169269100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-169269100-1');
</script>
<script data-ad-client="ca-pub-9170822913059220" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Jobyfied</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700|Work+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">
    
    
    
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  
    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
	  <link rel="stylesheet" type="text/css"
          href="fonts/neo fobia/stylefont.css"/>
    
  </head>
  <body>
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Ads Unit -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:50px"
     data-ad-client="ca-pub-9170822913059220"
     data-ad-slot="3145814261"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->
    
    
     <div class="site-navbar-wrap js-site-navbar bg-white">
      
      <div class="container">
        <div class="site-navbar bg-light">
          <div class="py-1">
            <div class="row align-items-center">
              <div class="col-2">
                <h2 class="mb-0 site-logo"><a href="index.php" style="font-family:'Neo Fobia Bold';font-weight:normal;font-size:30px" >JOBYFIED</a></h2>
				<p style="font-size: 14.6px; color: black;">Simplyfing Job Search</p>
              </div>
              <div class="col-10">
                <nav class="site-navigation text-right" role="navigation">
                  <div class="container">
                    <div class="d-inline-block d-lg-none ml-md-0 mr-auto py-3"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

                    <ul class="site-menu js-clone-nav d-none d-lg-block">
                      <li><a href="postjob.php"><span class="bg-primary text-white py-3 px-4 rounded"><span class="icon-plus mr-3"></span>Post New Job</span></a></li>
                    </ul>
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  
    <div style="height: 113px;"></div>
	  
    <div class="unit-5 overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container text-center">
        <h2 class="mb-0">IT &amp; Networking Jobs</h2>
        <p class="mb-0 unit-6"><a href="index.php">Home</a> <span class="sep">/</span> <span>IT &amp; Networking jobs</span></p>
      </div>
    </div>
	  <div class="container">
	  	  <div class="site-section bg-light">
	  <div class="col-md-12 block-16">
  <div class="d-flex mb-0">
              <h2 class="mb-5 h3 mb-0">IT &amp; Networking Jobs</h2>
            </div>
	  </div>

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1393 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Female IT Assistant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1340 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>COMPUTER OPERATOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1160 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Technician - Female only</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1159 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Marketing & Social Media (Specialist / Manager)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1146 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Web Developer / Web Designer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Ansar Group</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1133 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1116 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MOBILE APP DEVELOPER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1107 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1104 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Programmer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1063 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT ENGINEER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=997 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Need Laptop Harware and Software Technication</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=995 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Computer Operator/Data Entry</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Othaim Markets</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=961 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Academic Head / IT Administrator required in Khi. </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=957 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Software Developer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=921 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Female Computer Operator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=915 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Support</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=913 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Female CSR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=906 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SAP CONSULTANT FOR IT DEPARTMENT (SECTION HEAD)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=905 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Web Developer (HTML, CSS, JS)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=872 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>System Administrator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=869 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>NETWORK ENGINEER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=810 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Support Engineer & Programmer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=728 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Fiber Optic splicing & Testing Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=721 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Laundry Technical/Application Expert</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=708 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>3D MODELING AND RENDERING</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=705 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PBX VoIP, windows engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Part Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=680 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=679 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Developer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=675 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=650 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>E-Marketing Specialist</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=632 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Fiber Optic Splicer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=608 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> IT Technical Support/Desktop Support/System Admin</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=605 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Web Developer/ SuiteCRM, Laravel and Plone Develop</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=604 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Information Technology Specialist</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=599 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>CNC Programmer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=597 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Dot Net Developer / Web Developer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=596 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Dot Net Developer / Web Developer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=568 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Social Media Promotion Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=560 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>CCNA - Netwrok Designer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=531 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Digital Marketing Manger</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=523 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Web Designer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=518 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Mobile Application Operational Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=512 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>System Engineer </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=511 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Tech Support</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=508 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Support/Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=497 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>E-Commerce Project Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=496 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PHP/Laravel INSTRUCTOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=494 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Automation Developer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=487 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Xamarin Forms Developers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=482 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>AXAPTA Consultant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=474 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=470 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Digital Marketing</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=439 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Network Administrator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=354 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>JDE Developer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=323 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Fiber Optic splicing & Testing Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

              <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=24 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>IT Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    
	 
</div>
   </div> 
    <footer class="site-footer">
      <div class="container">
         <div class="col-md-12 text-center">
                <p><a href="index.php" style="font-family:'Neo Fobia Bold';font-weight:normal;font-size:40px; color: #FFFFFF;" >JOBYFIED</a></p>
			    <p style="font-size: 16px; color: #FFFFFF;">Simplyfing Job Search</p>
              </div>
		  <br>
        <div class="text-center">
          <div class="col-md-12">
            <p style="color: white;">
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All Rights Reserved | This Website Made By <a href="http://www.digitadm.com/" style="color: green;">Digita Digital Marketing.</a>
            </p>
          </div>
          
        </div>
      </div>
    </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  
  <script src="js/mediaelement-and-player.min.js"></script>

  <script src="js/main.js"></script>
    

  <script>
      document.addEventListener('DOMContentLoaded', function() {
                var mediaElements = document.querySelectorAll('video, audio'), total = mediaElements.length;

                for (var i = 0; i < total; i++) {
                    new MediaElementPlayer(mediaElements[i], {
                        pluginPath: 'https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/',
                        shimScriptAccess: 'always',
                        success: function () {
                            var target = document.body.querySelectorAll('.player'), targetTotal = target.length;
                            for (var j = 0; j < targetTotal; j++) {
                                target[j].style.visibility = 'visible';
                            }
                  }
                });
                }
            });
    </script>


    <script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&libraries=places&callback=initAutocomplete"
        async defer></script>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Ads Unit -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:50px"
     data-ad-client="ca-pub-9170822913059220"
     data-ad-slot="3145814261"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
  </body>
</html>