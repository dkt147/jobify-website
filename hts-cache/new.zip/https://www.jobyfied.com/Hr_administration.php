
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-169269100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-169269100-1');
</script>
<script data-ad-client="ca-pub-9170822913059220" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Jobyfied</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700|Work+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">
    
    
    
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  
    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
	  <link rel="stylesheet" type="text/css"
          href="fonts/neo fobia/stylefont.css"/>
    
  </head>
  <body>
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Ads Unit -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:50px"
     data-ad-client="ca-pub-9170822913059220"
     data-ad-slot="3145814261"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->
    
    
     <div class="site-navbar-wrap js-site-navbar bg-white">
      
      <div class="container">
        <div class="site-navbar bg-light">
          <div class="py-1">
            <div class="row align-items-center">
              <div class="col-2">
                <h2 class="mb-0 site-logo"><a href="index.php" style="font-family:'Neo Fobia Bold';font-weight:normal;font-size:30px" >JOBYFIED</a></h2>
				<p style="font-size: 14.6px; color: black;">Simplyfing Job Search</p>
              </div>
              <div class="col-10">
                <nav class="site-navigation text-right" role="navigation">
                  <div class="container">
                    <div class="d-inline-block d-lg-none ml-md-0 mr-auto py-3"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

                    <ul class="site-menu js-clone-nav d-none d-lg-block">
                      <li><a href="postjob.php"><span class="bg-primary text-white py-3 px-4 rounded"><span class="icon-plus mr-3"></span>Post New Job</span></a></li>
                    </ul>
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  
    <div style="height: 113px;"></div>
	  
    <div class="unit-5 overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container text-center">
        <h2 class="mb-0">HR And Administration Jobs</h2>
        <p class="mb-0 unit-6"><a href="index.php">Home</a> <span class="sep">/</span> <span>HR And Administration jobs</span></p>
      </div>
    </div>
	  <div class="container">
	  	  <div class="site-section bg-light">
	  <div class="col-md-12 block-16">
  <div class="d-flex mb-0">
              <h2 class="mb-5 h3 mb-0">HR And Administration Jobs</h2>
            </div>
	  </div>

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1400 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Officer / PRO</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1392 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Administrator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1384 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Mandoob required </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1383 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Admin Assistant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1372 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Receptionist </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1365 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PRO</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1363 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>BUSINESS EXECUTIVES</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1350 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Social Media Administrator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1349 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Executive</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1346 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1334 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1331 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> SALES EXECUTIVE / HR / PRO</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1319 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Receptionist / Admin with Accounting Background</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1308 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>LOGISTICS MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1307 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>OPERATIONS CO-ORDINATOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1305 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>OPERATION MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1293 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Administrative staff</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1289 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Document Controller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1283 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Camp Boss and Office Boy</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1278 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Purchaser</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1277 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> Executive Secretary (Lady)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1261 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> Lady HR / Immigration Officer </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1256 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Production Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1254 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>General Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1251 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> MARKETING MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1250 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Office Admin</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1248 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1247 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Admin Transportation supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1225 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Admin Assistant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1222 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> PROPERTY SUPERVISOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1221 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Document Controller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1218 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Camp Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1211 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1205 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Project Specialist</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1199 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Hypermarket Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1198 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Admin Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1181 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>LOCAL HIRING for Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1180 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Business Developer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1167 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> Operations Manager (Arab Nationals OnlySenior Lev</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1154 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>OPERATIONS MANAGER with NOC</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1149 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Operational Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1143 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Junior Clerk</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1120 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Shop Manager Cum Senior Purchase </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1112 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Procurement Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1098 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Admin Staff</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1091 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Shop Manager Cum Senior Purchaser</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1077 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>House Manager (FEMALE)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>For House</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1067 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>OPERATIONS MANAGER/PUBLIC RELATION MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1049 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PRO</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1041 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>FEMALE OFFICE ADMIN</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1033 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Looking for a Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1028 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PUBLIC RELATION OFFICER / MANDOOB</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1022 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Hire Desk</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1018 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Document Controller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=999 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PROCUREMENT MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>SAS FLARE INTERNATIONAL CO. LTD.</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=978 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>BARISTA, DCDP, COMMIE WAITER, STOREKEEPER, HR GENE</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>United Group Qatar</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=967 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=964 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Accountant / Internal Auditor / Admin Assistant. </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=958 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=941 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Customer service female for logistic company</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=933 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Front Desk Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=930 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Female Admin Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=916 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Female Coordinator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=896 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Required experienced HR & Admin Executive</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=894 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Purchaser</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=874 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Executive Secretary</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=865 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Assistant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=859 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR/Secretary</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=850 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Admin Coordinator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=843 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=833 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Admin Coordinator for Workshop</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=825 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Collector</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=820 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Admin Coordinator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=804 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Urgent requirement for Qatar company</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=770 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Business Development Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=767 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Secretary cum Document Controller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=757 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Female Secretary / Office Assistant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=726 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Document Controller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=725 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Female Executive Secretary</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=709 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Female Coordinator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=695 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Business development</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=689 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Document Controller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=672 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Purchase Assistant </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=670 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Office Clerk</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=657 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR & Personal Accountant / Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=655 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Oracle HRMS Consultant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=649 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Consultant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=641 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>OFFICE GIRL/OFFICE BOY</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=619 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Human Resources (HR) Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=616 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Secretary/Document Controller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>NORTH EMDAD CONTRACTING COMPANY</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=586 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=585 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Procurement Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=582 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DOCUMENT CONTROLLER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=551 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SAP PAYROLL OFFICER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=550 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SAP PAYROLL OFFICER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>ASMACS GROUP</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=545 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Executive Secretary</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=538 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Document Controller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=536 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Accountant Cum Admin Incharge</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=527 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Office Assistant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=498 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MATERIAL RECEIVING INSPECTOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>United Construction</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=485 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Project Coordinator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=459 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Purchaser</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=453 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Procurement Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=441 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Sales & Procurement</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=435 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=433 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Planner</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=421 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Material Receiving QC Inspector</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=420 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Procurement QC Supervisor E&I</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=412 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Inventory Management Executive</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=391 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Procurement Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=387 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Store Keeper</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=366 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Plant Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=358 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Contract Administrator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=350 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SENIOR SALES SUPERVISOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=342 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>CONTRACT ADMINISTRATOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=321 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Document Controller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=312 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Field Coordinator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=310 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Coordinator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=306 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>OFFICE BOY</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=305 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=304 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Office Boy</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=303 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Receptionists</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=292 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Camp Boss</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=290 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>BUSINESS DEVELOPMENT EXECUTIVE</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=289 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SECRETARY</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=278 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PRO</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=274 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DOCUMENT CONTROLLER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=268 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>OFFICE BOY </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=258 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>STOREKEEPER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=255 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ADMIN OFFICER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=254 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SECRETARY </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=253 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DOCUMENT CONTROLLER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=248 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PROCUREMENT ENGINEER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=245 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>CONTRACT ADMINISTRATOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=233 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SECRETARY</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=232 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Executive</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=229 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PRO (Mandoob)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=225 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>OPERATIONS MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=223 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Procurement Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span> MELIORA CONSTRUCTION SOLUTION</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=218 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Representative</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=167 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PRINCIPAL</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=111 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HR Assistant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

         	<div class="rounded border jobs-wrap">
		<a href=job-description.php?id=110 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Procurement </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    
	 
</div>
   </div> 
    <footer class="site-footer">
      <div class="container">
         <div class="col-md-12 text-center">
                <p><a href="index.php" style="font-family:'Neo Fobia Bold';font-weight:normal;font-size:40px; color: #FFFFFF;" >JOBYFIED</a></p>
			    <p style="font-size: 16px; color: #FFFFFF;">Simplyfing Job Search</p>
              </div>
		  <br>
        <div class="text-center">
          <div class="col-md-12">
            <p style="color: white;">
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All Rights Reserved | This Website Made By <a href="http://www.digitadm.com/" style="color: green;">Digita Digital Marketing.</a>
            </p>
          </div>
          
        </div>
      </div>
    </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  
  <script src="js/mediaelement-and-player.min.js"></script>

  <script src="js/main.js"></script>
    

  <script>
      document.addEventListener('DOMContentLoaded', function() {
                var mediaElements = document.querySelectorAll('video, audio'), total = mediaElements.length;

                for (var i = 0; i < total; i++) {
                    new MediaElementPlayer(mediaElements[i], {
                        pluginPath: 'https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/',
                        shimScriptAccess: 'always',
                        success: function () {
                            var target = document.body.querySelectorAll('.player'), targetTotal = target.length;
                            for (var j = 0; j < targetTotal; j++) {
                                target[j].style.visibility = 'visible';
                            }
                  }
                });
                }
            });
    </script>


    <script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&libraries=places&callback=initAutocomplete"
        async defer></script>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Ads Unit -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:50px"
     data-ad-client="ca-pub-9170822913059220"
     data-ad-slot="3145814261"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
  </body>
</html>