
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-169269100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-169269100-1');
</script>
<script data-ad-client="ca-pub-9170822913059220" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Jobyfied</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700|Work+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">
    
    
    
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  
    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
	  <link rel="stylesheet" type="text/css"
          href="fonts/neo fobia/stylefont.css"/>
    
  </head>
  <body>
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Ads Unit -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:50px"
     data-ad-client="ca-pub-9170822913059220"
     data-ad-slot="3145814261"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->
    
    
     <div class="site-navbar-wrap js-site-navbar bg-white">
      
      <div class="container">
        <div class="site-navbar bg-light">
          <div class="py-1">
            <div class="row align-items-center">
              <div class="col-2">
                <h2 class="mb-0 site-logo"><a href="index.php" style="font-family:'Neo Fobia Bold';font-weight:normal;font-size:30px" >JOBYFIED</a></h2>
				<p style="font-size: 14.6px; color: black;">Simplyfing Job Search</p>
              </div>
              <div class="col-10">
                <nav class="site-navigation text-right" role="navigation">
                  <div class="container">
                    <div class="d-inline-block d-lg-none ml-md-0 mr-auto py-3"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

                    <ul class="site-menu js-clone-nav d-none d-lg-block">
                      <li><a href="postjob.php"><span class="bg-primary text-white py-3 px-4 rounded"><span class="icon-plus mr-3"></span>Post New Job</span></a></li>
                    </ul>
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  
    <div style="height: 113px;"></div>
	  
    <div class="unit-5 overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container text-center">
        <h2 class="mb-0">Restaurant / Food Service Jobs</h2>
        <p class="mb-0 unit-6"><a href="index.php">Home</a> <span class="sep">/</span> <span>Restaurant / Food Service jobs</span></p>
      </div>
    </div>
	  <div class="container">
	  	  <div class="site-section bg-light">
	  <div class="col-md-12 block-16">
  <div class="d-flex mb-0">
              <h2 class="mb-5 h3 mb-0">Restaurant / Food Service Jobs</h2>
            </div>
	  </div>

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1389 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Shift Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1377 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1361 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>WALK-IN INTERVIEW</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Al Jassim Group</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1353 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1328 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Health & Food Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1322 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1309 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cost Controller / Accountant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1292 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Male Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1285 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Pastry / Baking Cook </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1280 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1276 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Waiter</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1274 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Staff Required</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1273 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Jobs in Doha</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1272 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Jobs in Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1265 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> RESTAURANT IS LOOKING FOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1234 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1207 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1206 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Waiter</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1200 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1191 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1185 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Assistant Chef for American Restaurant in Doha</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1178 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Assistant Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1162 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Bakery Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1151 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1135 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Coffee Shop Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1126 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1109 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Kitchen Staff</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1072 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Manager and Assistant Restaurant Manage</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1070 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1015 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Operations Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=990 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Service Crew Jobs available for restaurants and ca</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=952 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Urgent jobs for Doha</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=932 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Hotel Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=891 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Urgently required Restaurant Staff</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=823 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MAWBIMA KABAYAN (Sri Lankan Restaurant)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>MAWBIMA KABAYAN (Sri Lankan Restaurant)</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=819 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Helper</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=818 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=812 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Indian Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=807 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=759 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Purchasing Manager/Stocker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=756 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant (bofia) worker, drivers, sales</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=749 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Seafood Restaurant need Indian Staff</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=735 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Grocery Store Delivery Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=734 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>15 Job vacancies</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=722 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HSE MANAGER - SPECIALIZED FOR CATERING AND HOSPITA</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=710 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook Indian/Arabic Food</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=687 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Assistance Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=674 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=673 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook - Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=668 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Chef Steward</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=665 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Deliverey man with CAR </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=661 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Barista- Juice Maker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=659 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Pancakes & Waffles Maker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=647 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Juice and Sweet Maker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=646 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Bukhari Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=639 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>salesman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=637 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=633 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Waiter</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=628 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Assistant Chef & Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=609 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Baker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=595 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=584 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Burger Maker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=579 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Pancake Maker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=567 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Noodles Restaurant Workers Required</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=564 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Motorbikes Driver for Restaurant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=556 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Residential Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=539 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=525 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Junior Marketing and Sales Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=524 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant & Coffee shop Operation Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=519 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Catering Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=513 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Pastry Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=510 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>House Chef Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=509 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Restaurant Manager/IT/Accountant</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=486 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Baker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>180 Degree KSA</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=437 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Assistant Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=436 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>ASMACS GROUP</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=401 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Bar Tender</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=398 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Bakery Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=381 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Waitress</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=349 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Barista and Baker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=339 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Juice Maker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=320 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HSE MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=311 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=215 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MOTORCYCLE RIDERS</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=214 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Waitress</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=213 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Waiter</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=212 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=211 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=210 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Cook</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=104 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Waiter</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=103 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Baker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=102 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=98 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=58 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Motorcycle Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=56 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Vehicle Driver</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=54 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Labor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=53 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Waiter</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=52 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Baker</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=51 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=49 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    

             <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=6 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Baking Chef</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
    
	 
</div>
   </div> 
    <footer class="site-footer">
      <div class="container">
         <div class="col-md-12 text-center">
                <p><a href="index.php" style="font-family:'Neo Fobia Bold';font-weight:normal;font-size:40px; color: #FFFFFF;" >JOBYFIED</a></p>
			    <p style="font-size: 16px; color: #FFFFFF;">Simplyfing Job Search</p>
              </div>
		  <br>
        <div class="text-center">
          <div class="col-md-12">
            <p style="color: white;">
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All Rights Reserved | This Website Made By <a href="http://www.digitadm.com/" style="color: green;">Digita Digital Marketing.</a>
            </p>
          </div>
          
        </div>
      </div>
    </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  
  <script src="js/mediaelement-and-player.min.js"></script>

  <script src="js/main.js"></script>
    

  <script>
      document.addEventListener('DOMContentLoaded', function() {
                var mediaElements = document.querySelectorAll('video, audio'), total = mediaElements.length;

                for (var i = 0; i < total; i++) {
                    new MediaElementPlayer(mediaElements[i], {
                        pluginPath: 'https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/',
                        shimScriptAccess: 'always',
                        success: function () {
                            var target = document.body.querySelectorAll('.player'), targetTotal = target.length;
                            for (var j = 0; j < targetTotal; j++) {
                                target[j].style.visibility = 'visible';
                            }
                  }
                });
                }
            });
    </script>


    <script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&libraries=places&callback=initAutocomplete"
        async defer></script>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Ads Unit -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:50px"
     data-ad-client="ca-pub-9170822913059220"
     data-ad-slot="3145814261"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
  </body>
</html>