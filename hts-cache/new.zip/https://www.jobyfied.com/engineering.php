
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-169269100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-169269100-1');
</script>
<script data-ad-client="ca-pub-9170822913059220" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Jobyfied</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Amatic+SC:400,700|Work+Sans:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/mediaelementplayer.min.css">
    
    
    
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  
    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
	  <link rel="stylesheet" type="text/css"
          href="fonts/neo fobia/stylefont.css"/>
    
  </head>
  <body>
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Ads Unit -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:50px"
     data-ad-client="ca-pub-9170822913059220"
     data-ad-slot="3145814261"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->
    
    
     <div class="site-navbar-wrap js-site-navbar bg-white">
      
      <div class="container">
        <div class="site-navbar bg-light">
          <div class="py-1">
            <div class="row align-items-center">
              <div class="col-2">
                <h2 class="mb-0 site-logo"><a href="index.php" style="font-family:'Neo Fobia Bold';font-weight:normal;font-size:30px" >JOBYFIED</a></h2>
				<p style="font-size: 14.6px; color: black;">Simplyfing Job Search</p>
              </div>
              <div class="col-10">
                <nav class="site-navigation text-right" role="navigation">
                  <div class="container">
                    <div class="d-inline-block d-lg-none ml-md-0 mr-auto py-3"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

                    <ul class="site-menu js-clone-nav d-none d-lg-block">
                      <li><a href="postjob.php"><span class="bg-primary text-white py-3 px-4 rounded"><span class="icon-plus mr-3"></span>Post New Job</span></a></li>
                    </ul>
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  
    <div style="height: 113px;"></div>
	  
    <div class="unit-5 overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container text-center">
        <h2 class="mb-0">Engineering Jobs</h2>
        <p class="mb-0 unit-6"><a href="index.php">Home</a> <span class="sep">/</span> <span>Engineering jobs</span></p>
      </div>
    </div>
	  <div class="container">
	  	  <div class="site-section bg-light">
	  <div class="col-md-12 block-16">
  <div class="d-flex mb-0">
              <h2 class="mb-5 h3 mb-0">Engineering Jobs</h2>
            </div>
	  </div>

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1406 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>WALK IN INTERVIEW</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1405 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Mechanical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1402 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Draftsman MEP - Coordinator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1401 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1399 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Quantity Surveyor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1397 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1387 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Project Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1386 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Doha Petroleum Construction Co. Ltd</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1385 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>LAND SURVEYORS</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1382 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Land Surveyor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1374 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DRAFTSMAN</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1371 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1362 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Project Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1360 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Quality Assurance Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1357 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Land Surveyor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1354 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1342 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>LAND SURVEYORS</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1337 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1333 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1329 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Planning Engineers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1325 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Vacancies</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1324 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DRAFTSMEN (CIVIL & ARCHITECTURAL</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1323 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Jobs in Doha</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1321 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA/QC Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1316 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Construction Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1314 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Planning Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1311 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SAFETY OFFICER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1304 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>RESIDENT ENGINEERS / SR. SITE ENGINEERS (ALL DISCI</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1303 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Qualified Land Surveyors / Survey Engineers </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1302 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1299 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>CIVIL ENGINEER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1298 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>JOB VACANCIES</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1297 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1294 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1291 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Safety Officer </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1282 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1270 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Surveyor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1269 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Environmental Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1267 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1245 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SAFETY INSPECTOR - LOCAL</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1244 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Senior ELV / Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1242 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> E&I Experienced Engineer for Government project,</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1238 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> ARCHITECTURAL BIM MODELERS</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Draw Lines Qatar</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1233 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Draftsman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1231 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Surveyor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1229 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering Jobs in Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1228 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>URGENT FOR LARGE BUILDING CONSTRUCTION COMPANY</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1226 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Defence Certified UPDA Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1217 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Hiring in Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1213 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>OIL & GAS (O&G) DIVISION Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1210 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Service Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1209 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Architect</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span> Universal Design Center</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1202 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Urgent Local Hiring for Construction company</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1194 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Quantity Surveyor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1189 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> Project Manager (Civil Engineer)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1187 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Site Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>ERIGO HYGIENE WATER TANK CLEANING & DISINFECTION S</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1186 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> QA/QC Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1173 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1170 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering Jobs in Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1168 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Safety Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1163 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1144 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Project Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1140 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1139 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Autocad Engineers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1138 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Safety Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1136 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering Jobs in Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1124 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Foreman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1122 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MEP Company Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1114 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELV Estimation Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1113 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Project Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1110 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>RELECTRICAL ENGINEER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1102 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electricians Required</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1100 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MEP Project Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1093 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Construction Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1089 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Fire Fighting Technicians</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1082 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Doha Based Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1081 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Doha Based Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1080 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DOHA BASED CONTRACTING COMPANY REQUIRES </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1079 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1078 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Architect / Interior Designer / 3D Modeler </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>New Vision Construction</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1074 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Planning Engineer - Civil</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1073 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Construction Company Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1065 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MARINE CONSTRUCTION COMPANY RECRUITMENT</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>MARINE CONSTRUCTION COMPANY</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1062 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1061 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Draftsman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1052 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Required for Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1044 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HVAC Technician/Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1040 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Project Managers/Contract Managers </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1032 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Urgently Required</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1021 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Landscape Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=1020 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Field Surveyor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=992 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRICAL SUPERVISOR/FOREMAN</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=991 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRICAL TECHNICIAN :KSA (LOCAL TRANSFER)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=972 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>AutoCAD Operator / Draftsman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=971 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Project Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=955 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HVAC Engineer & Marketing Executive </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=950 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=938 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Planning Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=936 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HAVC SUPERVISOR :KSA (LOCAL TRANSFER)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=934 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Textile Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>pakistan</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=908 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Jobs at Parsons (Apply Now)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=904 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=903 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QC Engineer / Civil Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=902 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Urgent requirement</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=901 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civi engineer and civil qc non aramco</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=900 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HVAC Mechanical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=893 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA/QC Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=892 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QC inspector (NDT Qualified)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=885 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>BMS Tech & Engineers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Private</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=876 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Reputed MEP company Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=864 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>System Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=856 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Requirements</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=848 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Engineer Required - Arabic</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=844 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=837 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> Civil engineer with transferable visa.</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=836 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HVAC DUCTS & DAMPERS SNR. PRODUCTION ENGINEER / PR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=831 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Maintenance Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=821 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Construction Company Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=815 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Walk in Interiews</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=808 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Meliora construction solution jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=806 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Construction company job</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=801 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Jobs for Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=799 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MARBU Contracting Co W.L.L  is hiring</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>MARBU Contracting Co W.L.L</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=797 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA/QC Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=794 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Hiring or Group of Companies in Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=791 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>URGENTLY REQUIRED in Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=787 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Urgent jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=785 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Structural Draftsman (RC)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=784 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Structural Engineer-Senior</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=780 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Jobs in Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=778 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRICAL MAINTENANCE ENGINEER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=777 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>UPDA Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=775 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Urgent requirement for Qatar company</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=773 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Safety Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=772 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Sr. Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=769 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Required for Qatar</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=762 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Agriculture Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=751 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Surveyor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=741 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Safety Officer Required (JEDDAH ONLY)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=740 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Safety Officer Required (JEDDAH ONLY)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=729 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering Jobs</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=704 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=700 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Engineer/Geologist</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=694 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical site/ Project engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=690 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Planning Engineer/Scheduler</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=685 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Safety Supervisor (Aramco Approval)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=684 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QC Manager - Mechanical</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=682 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Planning Engineer, Quantity Surveyor-Mechanical, Q</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=678 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ARCHITECT 3D Draftsman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=677 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer with Aramco Experience</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=669 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>General Forman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=662 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Architect Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=644 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer (Testing)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=640 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA Manager Aramco approved with SAP NO</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=634 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QC Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=625 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Draftsman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=623 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Mechanical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=615 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Equipment Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=614 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=607 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Material Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=606 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Engineering Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=591 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>BMS Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=590 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Construction Manager (Civil)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=589 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil QC Inspector</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=580 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Mechanical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=577 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Safety Officer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=557 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Environmental Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=553 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QC INSPECTOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=546 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRICAL, MECHANICAL and CIVIL engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=544 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=540 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=533 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Structural Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=532 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Draftsman - BIM & Revit</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=505 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Project Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=504 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QC Inspector</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=491 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Draftman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=490 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Quality Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=489 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Planning Engineering</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=481 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Repair Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=480 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Contracts Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Akbar Group</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=478 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Al Yousuf Contracting</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=475 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QC Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Al Yousuf Contracting</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=472 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Safety Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=464 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Mechanical Design Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=463 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA/ QC Inspector</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=462 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA/QC Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=461 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Construction Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=449 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRICAL ENGINEER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=445 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Safety Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>PIONEER INTERNATIONAL GENERAL Cont. Est.</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=442 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Construction Manager (Civil/Mechanical)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=440 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=418 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Calibration Technician-ElectroMechanical</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=415 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Low Current Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=414 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Planning Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=413 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=405 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Project Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=404 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QC Civil Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=397 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRONICS TECHNICIAN</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=396 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=395 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SURVEYOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=393 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ACAD Draftsman (Electrical and Instrumentation)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=388 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Communication Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=385 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=371 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Maintenance Technician-Electrical</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=370 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Maintenance Technician-Electrical</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=369 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Maintenance Technician-Mechanical</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=356 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SCAFFOLDER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=343 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electro Mechanic Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=341 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Precast Mech. Draftsmen</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>other</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=328 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HSE Coordinator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=327 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA/QC Inspector</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=326 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Instrument Planner</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=325 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Planner</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=322 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Site Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=294 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRICAL SUPERVISOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=286 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Architect (Interior Design)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=285 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Structural Draftsman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=284 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Structural BIM Modeller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=283 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Mechanical BIM Modeller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=282 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical BIM Modeller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=277 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SAFETY OFFICER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=276 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SAFETY OFFICER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=275 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MEP FOREMAN</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=273 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>DRAFTSMAN (AUTOCAD, REVIT)</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=272 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA/QC ENGINEER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=271 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MEP TECHNICAL ENGINEER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=270 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PLANNING ENGINEER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=269 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MEP ENGINEER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=266 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MECHANICIAN </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=252 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA/QC ENGINEER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=251 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SAFETY OFFICER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=250 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>LAND SURVEYOR </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=249 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SITE ENGINEER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=247 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QUANTITY SURVEYOR </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=246 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QUANTITY SURVEYOR </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=244 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA/QC Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=243 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PLANNING MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=242 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SAFETY MANAGER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=241 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>CONSTRUCTION MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=240 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>TECHNICAL MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=239 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PROJECT MANAGER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=238 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Mechanical & Electrical Moduler Expert</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=231 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Foreman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=228 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRICAL DRAFTMAN</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=227 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRICAL ENGINEER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=226 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PROJECT MANAGER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=224 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRICAL ENGINEER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>MELIORA CONSTRUCTION SOLUTION</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=222 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Plant Service Equipment Maintenance Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=219 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Foreman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=200 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Project Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=196 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>CIVIL FOREMAN </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=195 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>STRUCTURAL FOREMAN </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=194 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA/QC-CIVIL </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=193 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>CIVIL SITE ENGINEER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=192 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PROJECT MANAGER-CIVIL </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=188 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=185 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRICAL ENGINEER </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=183 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>SCAFFOLDERS (Certified) </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=181 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>ELECTRICAL TECHNICIANS </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=175 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Draughtsman (Experienced in Tensile Industry) </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=173 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Structural Design and Estimation Engineer </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=166 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>PROJECT SALES ENGINEER</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=140 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Infrastructure Draftsman </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=139 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil 3D Draftsman Structural Draftsman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=138 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Sr. Structural BIM Modeller MEP BIM Modeller</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=130 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>BMS ENGINEERS/TECHNICIANS </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=116 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Mechanical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=115 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=114 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Finishing Engineers </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=113 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Civil Quantity Surveyors </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=112 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>QA/QC Engineers  </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=109 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Project Manager/Construction Manager </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=108 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MEP Supervisor/Foreman </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=107 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>MEP Supervisor/Foreman </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=106 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Draftsman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=105 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Quantity Surveyor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=89 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Supervisor</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=80 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrical Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=77 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Mason</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=75 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Painter</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=72 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>AC Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=70 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Plumber</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=68 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=66 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Appliance Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=61 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Road/Grading Draftsman</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=60 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Senior Structural Design Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=42 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Projects Engineer</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=41 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Projects Manager</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=39 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Designers</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=37 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Auto Cad Draughtsmen </h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=34 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3> MEP BIM MODELERS</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=33 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>STRUCTURAL & ARCHITECTURAL BIM COORDINATOR</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=21 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Valve Operator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=19 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Pump Operator</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=17 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=11 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Plumber</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=9 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>HVAC Technician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    

			  <div class="rounded border jobs-wrap">
		<a href=job-description.php?id=7 class='job-item d-block d-md-flex align-items-center  border-bottom fulltime'>                <div class="job-details h-100">
                  <div class="p-3 align-self-center">
                    <h3>Electrician</h3>
                    <div class="d-block d-lg-flex">
                      <div class="mr-3"><span class="icon-suitcase mr-1"></span>Confidential</div>
                      <div class="mr-3"><span class="icon-room mr-1"></span>qatar</div>
                    </div>
                  </div>
                </div>
                <div class="job-category align-self-center">
                  <div class="p-3">
                    <span class="text-info p-2 rounded border border-info">Full Time</span>
                  </div>
                </div>  
              </a>
		</div>
     
    
	 
</div>
   </div> 
    <footer class="site-footer">
      <div class="container">
         <div class="col-md-12 text-center">
                <p><a href="index.php" style="font-family:'Neo Fobia Bold';font-weight:normal;font-size:40px; color: #FFFFFF;" >JOBYFIED</a></p>
			    <p style="font-size: 16px; color: #FFFFFF;">Simplyfing Job Search</p>
              </div>
		  <br>
        <div class="text-center">
          <div class="col-md-12">
            <p style="color: white;">
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All Rights Reserved | This Website Made By <a href="http://www.digitadm.com/" style="color: green;">Digita Digital Marketing.</a>
            </p>
          </div>
          
        </div>
      </div>
    </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  
  <script src="js/mediaelement-and-player.min.js"></script>

  <script src="js/main.js"></script>
    

  <script>
      document.addEventListener('DOMContentLoaded', function() {
                var mediaElements = document.querySelectorAll('video, audio'), total = mediaElements.length;

                for (var i = 0; i < total; i++) {
                    new MediaElementPlayer(mediaElements[i], {
                        pluginPath: 'https://cdn.jsdelivr.net/npm/mediaelement@4.2.7/build/',
                        shimScriptAccess: 'always',
                        success: function () {
                            var target = document.body.querySelectorAll('.player'), targetTotal = target.length;
                            for (var j = 0; j < targetTotal; j++) {
                                target[j].style.visibility = 'visible';
                            }
                  }
                });
                }
            });
    </script>


    <script>
      // This example displays an address form, using the autocomplete feature
      // of the Google Places API to help users fill in the information.

      // This example requires the Places library. Include the libraries=places
      // parameter when you first load the API. For example:
      // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

      var placeSearch, autocomplete;
      var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
      };

      function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
            {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        autocomplete.addListener('place_changed', fillInAddress);
      }

      function fillInAddress() {
        // Get the place details from the autocomplete object.
        var place = autocomplete.getPlace();

        for (var component in componentForm) {
          document.getElementById(component).value = '';
          document.getElementById(component).disabled = false;
        }

        // Get each component of the address from the place details
        // and fill the corresponding field on the form.
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
            document.getElementById(addressType).value = val;
          }
        }
      }

      // Bias the autocomplete object to the user's geographical location,
      // as supplied by the browser's 'navigator.geolocation' object.
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&libraries=places&callback=initAutocomplete"
        async defer></script>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Ads Unit -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:50px"
     data-ad-client="ca-pub-9170822913059220"
     data-ad-slot="3145814261"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
  </body>
</html>